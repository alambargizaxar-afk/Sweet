package com.sweetcrush.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.os.Build;
import android.content.pm.ActivityInfo;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setStatusBarColor(Color.rgb(255, 240, 247));
        getWindow().setNavigationBarColor(Color.rgb(255, 240, 247));
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(255, 249, 252));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("UTF-8");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (web != null) web.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){" +
            "var modal=document.getElementById('modal');if(modal&&modal.classList.contains('show')){modal.classList.remove('show');return 'modal';}" +
            "var ids=['game','settings','worlds','levels','collection','donate','achievements'];" +
            "for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&e.classList.contains('active')){" +
            "document.querySelectorAll('.screen').forEach(function(s){s.classList.remove('active')});" +
            "var h=document.getElementById('home');if(h)h.classList.add('active');" +
            "if(typeof updateHome==='function')updateHome();return 'home';}}return 'exit';})()", value -> {
                if (value == null || value.contains("exit")) finish();
            });
    }

    @Override protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.stopLoading(); web.destroy(); web = null; }
        super.onDestroy();
    }
}
