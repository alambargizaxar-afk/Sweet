SWEET CRUSH — ANDROID PROJECT

У проєкті є гра в app/src/main/assets/index.html та Android-застосунок на базі WebView.
Гра працює офлайн. Прогрес і налаштування зберігаються локально на телефоні.

ЯК ОТРИМАТИ APK:
1. На комп'ютері встановіть Android Studio.
2. Розпакуйте цей ZIP.
3. В Android Studio натисніть Open та виберіть папку SweetCrushAndroid.
4. Дочекайтеся Gradle Sync. Якщо Android Studio попросить, встановіть Android SDK Platform 35.
5. Виберіть Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Після завершення натисніть Locate. Файл буде в app/build/outputs/apk/debug/app-debug.apk.
7. Перенесіть APK на телефон Android і відкрийте його для встановлення. Android може попросити дозволити встановлення з цього джерела.

ВИМОГИ:
- Android Studio з Android SDK Platform 35
- JDK 17 або сумісний JDK, який рекомендує ваша версія Android Studio
- Інтернет потрібен лише для першого завантаження Gradle та Android Gradle Plugin.

ВАЖЛИВО:
Цей ZIP — вихідний проєкт, а не готовий APK. У середовищі створення файлів немає Android SDK і Gradle, тому скомпілювати та перевірити APK тут неможливо.
Платіжний сервіс для кнопки підтримки не підключений. Кнопка не списує гроші.

АВТОМАТИЧНЕ ЗБИРАННЯ APK ЧЕРЕЗ GITHUB (БЕЗ ANDROID STUDIO):
1. Створи репозиторій на GitHub.
2. Завантаж у нього всі файли та папки з цього ZIP (не сам ZIP).
3. Відкрий вкладку Actions у репозиторії та дозволь запуск workflows, якщо GitHub запитає.
4. Вибери "Build Sweet Crush APK" і натисни "Run workflow". Також збірка запускається автоматично після завантаження змін у main/master.
5. Коли збірка завершиться успішно, відкрий її сторінку, знайди Artifacts та завантаж "SweetCrush-APK".
6. Розпакуй завантажений архів — усередині буде app-debug.apk. Перенеси його на телефон і встанови.

Примітка: GitHub створює APK у хмарі. Цей проєкт не містить уже скомпільованого APK.
